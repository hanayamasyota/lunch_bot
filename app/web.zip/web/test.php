<?php 

$num = $_GET["number"];

echo $num;
echo "aiueo";
?>